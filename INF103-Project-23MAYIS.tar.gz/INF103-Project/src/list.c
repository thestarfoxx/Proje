#include "list.h"

#include <stdlib.h>
#include <string.h>
#include <stdio.h>

struct node* add_word(struct node *list, char *word) {
    struct node *cur = NULL;
#ifdef WITH_UTHASH
    /* TODO: Hash kodu */
#else
    /* TODO: Bagli liste kodu */
    while(list->next != NULL){
    	if(strcmp(word,list->word)==0) list->count++;
    	else{
    		struct node* new_node = (struct node*) malloc(sizeof(struct node));
    		new_node->word  = word;
    		new_node->count =   1 ;
    		new_node->next  = list;
    		return new_node;
    	}
    }
#endif
}

#include "list.h"

#include <stdlib.h>
#include <string.h>
#include <stdio.h>

struct node* add_word(struct node *list, char *word) {
    struct node *cur = NULL;
#ifdef WITH_UTHASH
    /* TODO: Hash kodu */
 struct node *new=malloc(sizeof(struct node));
 struct node *s = malloc ( sizeof ( struct node) );
 new->word= word;
 new->count= 0;
 cur=list;
 //hash tablosunda arama
   HASH_FIND_STR ( list ,word, s);
if(s){
//bulduysa kelimenin sayısını artır struct döndur
cur->count++;
list=cur;
}
else{
	//düğümü tabloya kaydetme
   HASH_ADD_KEYPTR ( hh , list , s -> word , strlen (s-> word ) , s) ;
	new->count = 1;
	list=new;

	}


    
#else
    /* TODO: Bagli liste kodu */
 cur=list;
while(cur != NULL){
if(strcmp(cur->word, word)==0){ 
                    cur->count++;
                    break;
            }
 cur=cur->next;
}
if(cur==NULL){
                    struct node *new= malloc(sizeof(struct node));
                    new->count=1;
                    new->word= word;
                    new->next = list;
                    list=new; 

}




#endif
            return list;

}

#include "list.h"

#include <stdlib.h>
#include <string.h>
#include <stdio.h>

struct node* add_word(struct node *list, char *word) {
    struct node *cur = NULL;
#ifdef WITH_UTHASH
    /* TODO: Hash kodu */



    
#else
    /* TODO: Bagli liste kodu */
 cur=list;
while(cur != NULL){
if(strcmp(cur->word, word)==0){ 
                    cur->count++;
                    break;
            }
 cur=cur->next;
}
                    struct node *new= malloc(sizeof(struct node));
                    new->count=1;
                    new->word= word;
                    new->next = list;
                    list=new; 






#endif
            return list;

}
